﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;
using System.Drawing.Imaging;
using Emgu.CV;
using Emgu.CV.Structure;


namespace WebcamSave
{
    public partial class Form1 : Form
    {
        private Capture capture;
        private bool captureInProgress;

        public Form1()
        {
            InitializeComponent();
        }
        private void ProcessFrame(object sender, EventArgs arg)
        {
            Image<Bgr, Byte> ImageFrame = capture.QuerySmallFrame();
            CamImgBox.Image = ImageFrame;

        }

        private void imageBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnstart_Click(object sender, EventArgs e)
        {
            #region if capture is not created create it now 
            if (capture == null)
            {
                try
                {
                    capture = new Capture();
                }
                catch (NullReferenceException excpt)
                {
                    MessageBox.Show(excpt.Message);
                }
            }
            #endregion
            if (capture != null)
            {
                if (captureInProgress)
                {
                    btnStart.Text = "Start!";
                    Application.Idle -= ProcessFrame;
                }
                else
                {
                    btnStart.Text = "Stop!";
                    Application.Idle += ProcessFrame;
                }
                captureInProgress = !captureInProgress;
            }


        }
        private void ReleaseData()
        {
            if (capture != null)
                capture.Dispose();
        }

        private void CaptureBox_Click(object sender, EventArgs e)
        {

        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            CaptureBox.Image = CamImgBox.Image;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "JPG(*.JPG|*.jpg";
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(CaptureBox.Width);
                int height = Convert.ToInt32(CaptureBox.Height);
                Bitmap bmp = new Bitmap(width, height);
                CaptureBox.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
                bmp.Save(dialog.FileName, ImageFormat.Jpeg);

            }
        }
    }
    }

